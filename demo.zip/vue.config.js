import Vue from 'vue'

export default {
    install: function(Vue){
        Vue.directive('pin', {
        bind: function (el, binding, vnode) {
            el.style.position = 'fixed'
            var s = (binding.arg == 'left' ? 'left' : 'top')
            el.style[s] = binding.value + 'px'
        }
    })
    }
}

