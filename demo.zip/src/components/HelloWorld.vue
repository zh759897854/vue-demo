<template xmlns:v-pin="http://www.w3.org/1999/xhtml" xmlns:v-colors="http://www.w3.org/1999/xhtml">
    <div class="hello">
        <slot name="two"></slot>
        <h1>{{ msg }}</h1>
        <slot></slot>
        <div id="dynamicexample">
            <h3>Scroll down inside this section ↓</h3>
            <p v-pin:[direction]="200">I am pinned onto the page at 200px to the left.</p>
            <div v-colors:[direction].bar="'red'">这是一个color指令</div>
        </div>
    </div>
</template>

<script>
    export default {
        name: 'HelloWorld',
        props: {
            msg: String
        },
        data() {
            return {
                direction: 'left'
            }
        },
        directives: {
            colors: {
                // 指令的定义
                bind: function (el, binding, vnode) {
                    el.style.color = binding.value;
                    console.log(binding)
                }
            }
        }
    }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="less">
    h3 {
        margin: 40px 0 0;
    }
    ul {
        list-style-type: none;
        padding: 0;
    }
    li {
        display: inline-block;
        margin: 0 10px;
    }
    a {
        color: #42b983;
    }
</style>
